import asyncio
import websockets

connected = {}  # Seznam připojených klientů
messages = []  # Seznam ukládající zprávy

async def handle_request(request):
    # Místo pro zpracování HTTP požadavku
    pass

async def handle_websocket(websocket, path):
    try:
        client_id = id(websocket)  # Unikátní identifikátor klienta na základě jejich spojení
        connected[client_id] = websocket  # Přidání klienta do seznamu připojených

        # Odeslat nově připojenému klientovi seznam existujících zpráv
        for message in messages:
            await websocket.send(message)

        async for message in websocket:
            print(f"{client_id}: {message}")

            # Přidat zprávu do seznamu
            message = f"{client_id}: {message}"
            messages.append(message)

            # Přeposlat zprávu všem ostatním klientům
            for other_id, client in connected.items():
                if other_id != client_id:
                    await client.send(message)
    except websockets.exceptions.ConnectionClosedError:
        pass
    finally:
        # Odstranit klienta z připojených po uzavření spojení
        if client_id in connected:
            del connected[client_id]

async def start_server():  # Spuštění serveru
    ip_address = "127.0.0.1"
    port = 8080
    server = await websockets.serve(handle_websocket, ip_address, port)
    await server.wait_closed()

asyncio.run(start_server())

async def handle_websocket(websocket, path):
    client_id = id(websocket)

    if client_id in banned_users:
        # Uživatel je banován, takže odpojíme spojení
        await websocket.close()
        return

    try:
        async for message in websocket:
            print(f"{client_id}: {message}")

            # Kontrola, zda zpráva obsahuje zakázané slovo
            if "Rum" in message:
                print(f"Banování uživatele {client_id} za slovo 'Rum'")
                banned_users.add(client_id)
                await websocket.close()
                return

            message = f"{client_id}: {message}"
            messages.append(message)

            # Přeposlat zprávu všem ostatním klientům
            for other_id, client in connected.items():
                if other_id != client_id:
                    await client.send(message)
    except websockets.exceptions.ConnectionClosedError:
        pass
    finally:
        if client_id in connected:
            del connected[client_id]
